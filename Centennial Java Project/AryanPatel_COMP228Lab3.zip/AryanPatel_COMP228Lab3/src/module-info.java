module AryanPatel_COMP228Lab3 {
	requires java.desktop;
}