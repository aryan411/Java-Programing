package exercise3;

public interface MortgageConstants {
	final int shTMortgage = 1;
	final int mTMortgage = 3;
	final int lTMortgage = 5;
	static final String bankName = "RBC";
	static final int maxMortgageAmount = 300000;
}
