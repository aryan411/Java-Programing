module AryanPatel_COMP228MidLabTest {
	requires java.desktop;
}