package exercise1;

public interface Coke {
	public abstract void cokePrice(double price);
}
