package exercise1;

public interface Onion {
public abstract void onionPrice(double price);
}
