package exercise3;

public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// calling all static methods
		OverloadObject.overLoading();
		OverloadObject.overLoading("one");
		OverloadObject.overLoading("Two", 2);
		OverloadObject.overLoading(4, 4);
	}

}
