module AryanPatel_COMP228Lab4 {
	requires javafx.controls;
	
	opens application to javafx.graphics, javafx.fxml;
}
	